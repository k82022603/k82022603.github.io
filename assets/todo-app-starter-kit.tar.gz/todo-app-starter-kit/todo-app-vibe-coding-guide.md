# 바이브코딩 실전 프로젝트: Todo 관리 앱

## 프로젝트 개요

이 문서는 바이브코딩의 세 가지 핵심 원칙을 실제로 적용하여 Todo 관리 앱을 개발하는 전 과정을 담고 있습니다. Claude Code를 사용하여 단계별로 구현하며, 각 단계에서 어떻게 AI와 소통해야 하는지 구체적인 프롬프트 예시를 제공합니다.

## 목차
1. [프로젝트 준비](#프로젝트-준비)
2. [기능 1: 할 일 추가](#기능-1-할-일-추가)
3. [기능 2: 할 일 목록 조회](#기능-2-할-일-목록-조회)
4. [기능 3: 할 일 완료 처리](#기능-3-할-일-완료-처리)
5. [기능 4: 할 일 삭제](#기능-4-할-일-삭제)
6. [기능 5: 할 일 필터링](#기능-5-할-일-필터링)
7. [검증 및 테스트](#검증-및-테스트)
8. [프로젝트 실행 방법](#프로젝트-실행-방법)

---

## 프로젝트 준비

### 기술 스택
- **프론트엔드**: React + TypeScript
- **스타일링**: Tailwind CSS
- **상태 관리**: React Hooks (useState, useEffect)
- **빌드 도구**: Vite
- **데이터 저장**: LocalStorage

### Claude Code에 제공할 첫 번째 프롬프트

```
프로젝트 초기 설정을 해주세요.

[기술 스택]
- React 18
- TypeScript
- Vite
- Tailwind CSS

[프로젝트 구조]
src/
  components/
  types/
  hooks/
  utils/
  App.tsx
  main.tsx

[요구사항]
1. Vite로 React + TypeScript 프로젝트를 생성
2. Tailwind CSS를 설정
3. 기본 폴더 구조를 생성
4. App.tsx에 "Todo App" 제목만 표시하는 기본 레이아웃 작성
5. 모바일 반응형을 고려한 컨테이너 설정 (max-w-2xl, mx-auto, p-4)

[제약사항]
- Create React App이 아닌 Vite를 사용해야 함
- 외부 UI 라이브러리는 사용하지 않음 (Tailwind CSS만 사용)
- ESLint와 Prettier 설정 포함

package.json, tsconfig.json, tailwind.config.js 등 모든 설정 파일을 생성해주세요.
```

### 예상 파일 구조
```
todo-app/
├── src/
│   ├── components/
│   ├── types/
│   │   └── index.ts
│   ├── hooks/
│   ├── utils/
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── public/
├── package.json
├── tsconfig.json
├── vite.config.ts
├── tailwind.config.js
└── README.md
```

---

## 기능 1: 할 일 추가

### 단계 1: 기능 쪼개기

할 일 추가 기능을 다음과 같이 작은 단위로 분해합니다:

1.1. Todo 데이터 타입 정의
1.2. 입력 폼 UI 컴포넌트 생성
1.3. 입력값 유효성 검증
1.4. Todo 추가 로직 구현
1.5. LocalStorage 저장 구현

### 단계 2: 요구사항 명확화

**1.1 Todo 데이터 타입 정의**

- **입력**: 없음 (타입 정의)
- **출력**: TypeScript interface
- **제약사항**:
  - id는 string 타입 (UUID 형식)
  - text는 string 타입 (할 일 내용)
  - completed는 boolean 타입 (완료 여부)
  - createdAt은 Date 타입 (생성 시간)
- **에러 처리**: 타입 정의이므로 해당 없음

**1.2 입력 폼 UI 컴포넌트**

- **입력**: 
  - onAdd: (text: string) => void (할 일 추가 콜백 함수)
- **출력**: React 컴포넌트
- **제약사항**:
  - 텍스트 입력 필드 + 추가 버튼
  - Enter 키로도 제출 가능
  - 제출 후 입력 필드 자동 초기화
  - 모바일에서도 사용하기 편한 크기의 버튼
- **에러 처리**:
  - 빈 문자열은 제출 불가
  - 공백만 있는 문자열은 제출 불가

**1.3 입력값 유효성 검증**

- **입력**: text: string
- **출력**: { isValid: boolean, errorMessage?: string }
- **제약사항**:
  - 최소 1자 이상
  - 최대 200자 이하
  - 공백만으로 구성된 문자열 불가
  - 앞뒤 공백은 자동 제거 (trim)
- **에러 처리**:
  - 빈 문자열: "할 일을 입력해주세요"
  - 200자 초과: "200자 이내로 입력해주세요"
  - 공백만: "유효한 할 일을 입력해주세요"

**1.4 Todo 추가 로직**

- **입력**: text: string
- **출력**: Todo 객체
- **제약사항**:
  - id는 crypto.randomUUID() 또는 Date.now() + Math.random() 조합 사용
  - createdAt은 현재 시간
  - completed는 false로 초기화
- **에러 처리**:
  - UUID 생성 실패 시 대체 방법 사용

**1.5 LocalStorage 저장**

- **입력**: todos: Todo[]
- **출력**: 없음 (부수 효과)
- **제약사항**:
  - 키 이름은 "todos"
  - JSON.stringify로 직렬화
- **에러 처리**:
  - LocalStorage 저장 실패 시 콘솔 경고 출력
  - 용량 초과 시 사용자에게 알림

### 단계 3: 실패 기준 정의

다음과 같은 경우는 실패로 간주합니다:

1. **빈 문자열로 Todo가 추가되면 실패**
   - 처리: 추가 버튼 비활성화 및 에러 메시지 표시

2. **공백만 있는 문자열로 Todo가 추가되면 실패**
   - 처리: trim 후 빈 문자열이면 에러 메시지 표시

3. **201자 이상의 문자열로 Todo가 추가되면 실패**
   - 처리: 입력 필드에 maxLength 설정 및 에러 메시지 표시

4. **중복된 ID가 생성되면 실패**
   - 처리: ID 생성 시 기존 ID와 중복 확인

5. **LocalStorage 저장 실패 시 데이터가 유실되면 실패**
   - 처리: try-catch로 에러를 잡고 사용자에게 알림

6. **페이지 새로고침 후 데이터가 사라지면 실패**
   - 처리: useEffect로 컴포넌트 마운트 시 LocalStorage에서 데이터 로드

### Claude Code에 제공할 프롬프트

```
할 일 추가 기능을 구현해주세요.

[1단계: Todo 타입 정의]
src/types/index.ts 파일을 생성하고 다음 interface를 정의해주세요:

interface Todo {
  id: string;         // UUID 형식
  text: string;       // 할 일 내용 (1-200자)
  completed: boolean; // 완료 여부
  createdAt: Date;    // 생성 시간
}

export { Todo };

[2단계: 유효성 검증 유틸리티]
src/utils/validation.ts 파일을 생성하고 다음 함수를 구현해주세요:

function validateTodoText(text: string): { isValid: boolean; errorMessage?: string } {
  // 구현 내용:
  // 1. 앞뒤 공백 제거 (trim)
  // 2. 빈 문자열 체크 → "할 일을 입력해주세요"
  // 3. 200자 초과 체크 → "200자 이내로 입력해주세요"
  // 4. 모두 통과하면 { isValid: true }
}

[3단계: LocalStorage 유틸리티]
src/utils/storage.ts 파일을 생성하고 다음 함수들을 구현해주세요:

const STORAGE_KEY = 'todos';

function saveTodos(todos: Todo[]): void {
  // try-catch로 에러 처리
  // JSON.stringify로 직렬화
  // 저장 실패 시 console.error
}

function loadTodos(): Todo[] {
  // try-catch로 에러 처리
  // JSON.parse로 역직렬화
  // Date 타입 복원 (createdAt은 string으로 저장되므로 new Date()로 변환)
  // 데이터 없거나 파싱 실패 시 빈 배열 반환
}

[4단계: TodoInput 컴포넌트]
src/components/TodoInput.tsx 파일을 생성하고 다음을 구현해주세요:

Props:
- onAdd: (text: string) => void

UI:
- 텍스트 입력 필드 (placeholder: "할 일을 입력하세요")
- 추가 버튼
- 에러 메시지 표시 영역

동작:
- 입력값 변경 시 실시간 유효성 검증
- 유효하지 않으면 버튼 비활성화 및 에러 메시지 표시
- Enter 키 또는 버튼 클릭으로 제출
- 제출 시 onAdd 콜백 호출
- 제출 후 입력 필드 초기화

스타일링:
- Tailwind CSS 사용
- 모바일 반응형
- 버튼 hover/disabled 상태 스타일
- 에러 메시지는 빨간색으로 표시

[실패 기준 - 다음 경우는 허용되지 않습니다]
1. 빈 문자열로 추가되는 경우
2. 공백만 있는 문자열로 추가되는 경우
3. 201자 이상의 문자열로 추가되는 경우
4. 제출 후 입력 필드가 초기화되지 않는 경우
5. 에러 메시지가 표시되지 않는 경우

[5단계: App.tsx 수정]
App.tsx를 수정하여 다음을 추가해주세요:

1. todos 상태 관리 (useState)
2. useEffect로 컴포넌트 마운트 시 LocalStorage에서 데이터 로드
3. todos 변경 시마다 LocalStorage에 저장
4. handleAddTodo 함수 구현:
   - 새 Todo 객체 생성 (id는 crypto.randomUUID() 사용, 없으면 Date.now() + Math.random())
   - todos 배열 업데이트
5. TodoInput 컴포넌트 렌더링

TypeScript 타입을 엄격하게 지켜주세요.
각 함수에 JSDoc 주석을 추가해주세요.
```

### 검증 체크리스트

생성된 코드를 다음 기준으로 검증합니다:

- [ ] 빈 문자열로 Todo 추가 시도 시 에러 메시지가 표시되는가?
- [ ] 공백만 있는 문자열로 Todo 추가 시도 시 에러 메시지가 표시되는가?
- [ ] 201자 문자열 입력 시 에러 메시지가 표시되는가?
- [ ] Todo 추가 후 입력 필드가 초기화되는가?
- [ ] Enter 키로 제출이 가능한가?
- [ ] 페이지 새로고침 후에도 데이터가 유지되는가?
- [ ] LocalStorage에 데이터가 올바른 형식으로 저장되는가?

---

## 기능 2: 할 일 목록 조회

### 단계 1: 기능 쪼개기

2.1. TodoList 컴포넌트 생성
2.2. TodoItem 컴포넌트 생성
2.3. 빈 상태 UI 표시
2.4. 목록 정렬 (최신순)

### 단계 2: 요구사항 명확화

**2.1 TodoList 컴포넌트**

- **입력**: 
  - todos: Todo[]
  - onToggle: (id: string) => void
  - onDelete: (id: string) => void
- **출력**: React 컴포넌트
- **제약사항**:
  - todos 배열을 순회하며 TodoItem 렌더링
  - 빈 배열일 때는 "할 일이 없습니다" 메시지 표시
- **에러 처리**: todos가 undefined일 경우 빈 배열로 처리

**2.2 TodoItem 컴포넌트**

- **입력**:
  - todo: Todo
  - onToggle: () => void
  - onDelete: () => void
- **출력**: React 컴포넌트
- **제약사항**:
  - 체크박스 + 텍스트 + 삭제 버튼
  - 완료된 항목은 취소선 및 회색 처리
  - 생성 시간 표시 (상대 시간: "5분 전", "1시간 전")
- **에러 처리**: 
  - todo가 null/undefined일 경우 null 반환
  - createdAt이 유효하지 않을 경우 "알 수 없음" 표시

**2.3 빈 상태 UI**

- **입력**: 없음
- **출력**: React 컴포넌트
- **제약사항**:
  - 아이콘 + 메시지
  - 가운데 정렬
  - 회색 텍스트
- **에러 처리**: 해당 없음

**2.4 목록 정렬**

- **입력**: todos: Todo[]
- **출력**: 정렬된 Todo[]
- **제약사항**:
  - 최신 항목이 위로 (createdAt 내림차순)
  - 원본 배열은 변경하지 않음 (immutable)
- **에러 처리**: 
  - createdAt이 없는 항목은 가장 아래로

### 단계 3: 실패 기준 정의

1. **할 일이 없을 때 빈 화면만 표시되면 실패**
   - 처리: "할 일이 없습니다" 메시지와 안내 표시

2. **완료된 항목이 시각적으로 구분되지 않으면 실패**
   - 처리: 취소선, 회색 처리, 체크박스 체크 상태

3. **목록이 정렬되지 않고 무작위로 표시되면 실패**
   - 처리: createdAt 기준 내림차순 정렬

4. **생성 시간이 표시되지 않으면 실패**
   - 처리: "5분 전" 형식의 상대 시간 표시

5. **체크박스나 삭제 버튼이 작동하지 않으면 실패**
   - 처리: onClick 이벤트 핸들러 연결

### Claude Code에 제공할 프롬프트

```
할 일 목록 조회 기능을 구현해주세요.

[1단계: 날짜 포맷 유틸리티]
src/utils/dateFormat.ts 파일을 생성하고 다음 함수를 구현해주세요:

function formatRelativeTime(date: Date): string {
  // 현재 시간과의 차이를 계산
  // 1분 미만: "방금 전"
  // 1시간 미만: "X분 전"
  // 24시간 미만: "X시간 전"
  // 그 외: "X일 전"
}

[2단계: TodoItem 컴포넌트]
src/components/TodoItem.tsx 파일을 생성하고 다음을 구현해주세요:

Props:
- todo: Todo
- onToggle: () => void
- onDelete: () => void

UI 레이아웃:
[체크박스] [할 일 텍스트] [생성 시간] [삭제 버튼]

동작:
- 체크박스 클릭 시 onToggle 호출
- 삭제 버튼 클릭 시 onDelete 호출
- completed가 true면:
  - 텍스트에 취소선 (line-through)
  - 텍스트 회색 처리 (text-gray-400)
  - 체크박스 체크 상태

스타일링:
- Flexbox 레이아웃
- 체크박스는 w-5 h-5
- 삭제 버튼은 hover 시 빨간색
- 모바일에서 터치하기 쉬운 크기
- 항목 간 구분선 또는 여백

[3단계: EmptyState 컴포넌트]
src/components/EmptyState.tsx 파일을 생성하고 다음을 구현해주세요:

UI:
- 📝 이모지 또는 아이콘
- "할 일이 없습니다" 메시지
- "위의 입력 필드에서 할 일을 추가해보세요" 안내 문구

스타일링:
- 가운데 정렬
- 회색 텍스트
- 적절한 여백

[4단계: TodoList 컴포넌트]
src/components/TodoList.tsx 파일을 생성하고 다음을 구현해주세요:

Props:
- todos: Todo[]
- onToggle: (id: string) => void
- onDelete: (id: string) => void

로직:
1. todos가 비어있으면 EmptyState 렌더링
2. todos를 createdAt 기준 내림차순 정렬
3. 정렬된 배열을 map으로 순회하며 TodoItem 렌더링
4. key는 todo.id 사용

스타일링:
- 목록 컨테이너에 적절한 여백
- 스크롤 가능하도록 설정

[5단계: App.tsx 수정]
App.tsx를 수정하여 다음을 추가해주세요:

1. handleToggleTodo 함수:
   - id를 받아서 해당 Todo의 completed 상태를 토글
   - todos 배열 업데이트 (불변성 유지)

2. handleDeleteTodo 함수:
   - id를 받아서 해당 Todo를 배열에서 제거
   - todos 배열 업데이트

3. TodoList 컴포넌트 렌더링:
   - todos, onToggle, onDelete props 전달

레이아웃:
- TodoInput은 상단 고정
- TodoList는 하단에 스크롤 가능하게

[실패 기준 - 다음 경우는 허용되지 않습니다]
1. 할 일이 없을 때 빈 화면만 표시되는 경우
2. 완료된 항목이 시각적으로 구분되지 않는 경우
3. 목록이 최신순으로 정렬되지 않는 경우
4. 생성 시간이 표시되지 않는 경우
5. 체크박스나 삭제 버튼이 작동하지 않는 경우
6. todo가 null일 때 에러가 발생하는 경우

TypeScript 타입을 엄격하게 지켜주세요.
```

### 검증 체크리스트

- [ ] 할 일이 없을 때 EmptyState가 표시되는가?
- [ ] 할 일이 최신순으로 정렬되어 표시되는가?
- [ ] 완료된 항목에 취소선과 회색 처리가 적용되는가?
- [ ] 생성 시간이 "X분 전" 형식으로 표시되는가?
- [ ] 체크박스 클릭 시 완료 상태가 토글되는가?
- [ ] 삭제 버튼 클릭 시 항목이 삭제되는가?
- [ ] 모바일에서도 버튼을 쉽게 클릭할 수 있는가?

---

## 기능 3: 할 일 완료 처리

### 단계 1: 기능 쪼개기

3.1. 완료 상태 토글 로직
3.2. 완료된 항목 카운트 표시
3.3. 완료 항목 필터링 옵션

### 단계 2: 요구사항 명확화

**3.1 완료 상태 토글**

- **입력**: id: string
- **출력**: 없음 (상태 업데이트)
- **제약사항**:
  - 해당 id의 Todo를 찾아 completed 값 반전
  - 불변성 유지 (map 사용)
- **에러 처리**:
  - 존재하지 않는 id면 경고 로그 출력
  - todos 배열은 변경하지 않음

**3.2 완료 항목 카운트**

- **입력**: todos: Todo[]
- **출력**: { total: number, completed: number }
- **제약사항**:
  - filter 사용하여 completed === true인 항목 카운트
- **에러 처리**: todos가 undefined면 { total: 0, completed: 0 }

**3.3 Stats 컴포넌트**

- **입력**: total: number, completed: number
- **출력**: React 컴포넌트
- **제약사항**:
  - "전체 X개 / 완료 Y개" 형식
  - 퍼센트 표시
- **에러 처리**: total이 0이면 "0%" 표시

### 단계 3: 실패 기준 정의

1. **존재하지 않는 id로 토글 시도 시 에러가 발생하면 실패**
   - 처리: id를 찾지 못하면 조용히 무시하고 경고 로그만 출력

2. **토글 시 다른 항목들이 영향을 받으면 실패**
   - 처리: map 사용하여 해당 항목만 변경

3. **완료 카운트가 실제와 다르게 표시되면 실패**
   - 처리: filter로 정확히 카운트

4. **total이 0일 때 나누기 에러가 발생하면 실패**
   - 처리: 조건문으로 0 체크

### Claude Code에 제공할 프롬프트

```
할 일 완료 처리 기능을 구현해주세요.

[1단계: Stats 컴포넌트]
src/components/Stats.tsx 파일을 생성하고 다음을 구현해주세요:

Props:
- total: number
- completed: number

UI:
- "전체 {total}개 / 완료 {completed}개 ({percentage}%)" 형식
- 진행률 바 (progress bar) 표시

로직:
- percentage 계산: total이 0이면 0%, 아니면 (completed / total * 100).toFixed(0)
- 진행률 바는 0-100% 범위로 시각화

스타일링:
- 깔끔한 카드 형태
- 진행률 바는 파란색 그라디언트
- 모바일 반응형

[2단계: App.tsx의 handleToggleTodo 개선]
기존 handleToggleTodo 함수를 다음과 같이 개선해주세요:

function handleToggleTodo(id: string): void {
  setTodos(prevTodos => {
    const todo = prevTodos.find(t => t.id === id);
    if (!todo) {
      console.warn(`Todo with id ${id} not found`);
      return prevTodos; // 변경하지 않고 반환
    }
    return prevTodos.map(todo =>
      todo.id === id
        ? { ...todo, completed: !todo.completed }
        : todo
    );
  });
}

[3단계: App.tsx에 통계 표시]
App.tsx를 수정하여 다음을 추가해주세요:

1. Stats 컴포넌트 import
2. todos 기반으로 total과 completed 계산
3. TodoInput과 TodoList 사이에 Stats 컴포넌트 렌더링

레이아웃:
- TodoInput
- Stats (여백 포함)
- TodoList

[실패 기준 - 다음 경우는 허용되지 않습니다]
1. 존재하지 않는 id로 토글 시 에러가 발생하는 경우
2. 토글 시 다른 항목의 completed 값이 변경되는 경우
3. total이 0일 때 percentage 계산에서 에러가 발생하는 경우
4. completed 카운트가 실제 값과 다른 경우
5. 진행률 바가 0% 미만 또는 100% 초과로 표시되는 경우
```

### 검증 체크리스트

- [ ] 통계가 정확하게 표시되는가?
- [ ] 항목 추가/삭제/완료 시 통계가 자동으로 업데이트되는가?
- [ ] total이 0일 때 에러가 발생하지 않는가?
- [ ] 진행률 바가 올바른 비율로 표시되는가?
- [ ] 존재하지 않는 id로 토글해도 에러가 발생하지 않는가?

---

## 기능 4: 할 일 삭제

### 단계 1: 기능 쪼개기

4.1. 삭제 로직 구현
4.2. 삭제 확인 다이얼로그
4.3. 일괄 삭제 기능 (완료된 항목만)

### 단계 2: 요구사항 명확화

**4.1 삭제 로직**

- **입력**: id: string
- **출력**: 없음 (상태 업데이트)
- **제약사항**:
  - filter 사용하여 해당 id가 아닌 항목만 남김
  - 불변성 유지
- **에러 처리**:
  - 존재하지 않는 id면 경고 로그
  - todos 배열은 변경하지 않음

**4.2 삭제 확인 다이얼로그**

- **입력**: 없음 (사용자 액션)
- **출력**: boolean (확인/취소)
- **제약사항**:
  - 브라우저 기본 confirm 사용 또는 커스텀 모달
  - "정말 삭제하시겠습니까?" 메시지
- **에러 처리**: 취소 시 아무 동작도 하지 않음

**4.3 일괄 삭제**

- **입력**: 없음 (버튼 클릭)
- **출력**: 없음 (상태 업데이트)
- **제약사항**:
  - completed === true인 항목만 삭제
  - 최소 1개 이상의 완료 항목이 있을 때만 버튼 활성화
- **에러 처리**: 완료 항목이 없으면 버튼 비활성화

### 단계 3: 실패 기준 정의

1. **삭제 확인 없이 바로 삭제되면 실패**
   - 처리: confirm 다이얼로그 표시

2. **존재하지 않는 id 삭제 시 에러가 발생하면 실패**
   - 처리: filter는 조용히 무시하므로 문제 없음, 경고 로그만 출력

3. **일괄 삭제 시 완료되지 않은 항목이 삭제되면 실패**
   - 처리: completed === true 조건으로 필터링

4. **완료 항목이 없을 때 일괄 삭제 버튼이 활성화되면 실패**
   - 처리: disabled 속성 동적으로 설정

### Claude Code에 제공할 프롬프트

```
할 일 삭제 기능을 구현해주세요.

[1단계: App.tsx의 handleDeleteTodo 개선]
기존 handleDeleteTodo 함수를 다음과 같이 개선해주세요:

function handleDeleteTodo(id: string): void {
  // 삭제 확인 다이얼로그
  const confirmed = window.confirm('정말 삭제하시겠습니까?');
  if (!confirmed) return;

  setTodos(prevTodos => {
    const todo = prevTodos.find(t => t.id === id);
    if (!todo) {
      console.warn(`Todo with id ${id} not found`);
      return prevTodos;
    }
    return prevTodos.filter(todo => todo.id !== id);
  });
}

[2단계: 일괄 삭제 기능]
App.tsx에 다음 함수를 추가해주세요:

function handleClearCompleted(): void {
  const completedCount = todos.filter(t => t.completed).length;
  if (completedCount === 0) return;

  const confirmed = window.confirm(
    `완료된 ${completedCount}개의 할 일을 삭제하시겠습니까?`
  );
  if (!confirmed) return;

  setTodos(prevTodos => prevTodos.filter(todo => !todo.completed));
}

[3단계: ClearButton 컴포넌트]
src/components/ClearButton.tsx 파일을 생성하고 다음을 구현해주세요:

Props:
- completedCount: number
- onClick: () => void

UI:
- "완료된 항목 삭제 ({completedCount}개)" 버튼
- completedCount가 0이면 비활성화

스타일링:
- 빨간색 계열 (destructive action)
- disabled 상태일 때 회색
- hover 효과

[4단계: App.tsx 레이아웃 수정]
Stats와 TodoList 사이에 ClearButton을 추가해주세요:

레이아웃 순서:
1. TodoInput
2. Stats
3. ClearButton (완료된 항목이 있을 때만 표시)
4. TodoList

[실패 기준 - 다음 경우는 허용되지 않습니다]
1. 삭제 확인 없이 바로 삭제되는 경우
2. 취소를 선택했는데 삭제되는 경우
3. 일괄 삭제 시 완료되지 않은 항목이 삭제되는 경우
4. 완료 항목이 없을 때 일괄 삭제 버튼이 활성화되는 경우
5. 존재하지 않는 id 삭제 시 앱이 크래시되는 경우
```

### 검증 체크리스트

- [ ] 개별 삭제 시 확인 다이얼로그가 표시되는가?
- [ ] 확인 다이얼로그에서 취소하면 삭제되지 않는가?
- [ ] 일괄 삭제 시 완료된 항목만 삭제되는가?
- [ ] 완료 항목이 없을 때 일괄 삭제 버튼이 비활성화되는가?
- [ ] 일괄 삭제 후 통계가 올바르게 업데이트되는가?

---

## 기능 5: 할 일 필터링

### 단계 1: 기능 쪼개기

5.1. 필터 옵션 정의 (전체/진행중/완료)
5.2. FilterButtons 컴포넌트
5.3. 필터링 로직
5.4. 필터 상태 저장

### 단계 2: 요구사항 명확화

**5.1 필터 타입 정의**

- **입력**: 없음 (타입 정의)
- **출력**: TypeScript type
- **제약사항**:
  - 'all' | 'active' | 'completed'
- **에러 처리**: 해당 없음

**5.2 FilterButtons 컴포넌트**

- **입력**:
  - currentFilter: FilterType
  - onFilterChange: (filter: FilterType) => void
- **출력**: React 컴포넌트
- **제약사항**:
  - 3개의 버튼 (전체/진행중/완료)
  - 현재 선택된 필터는 시각적으로 강조
- **에러 처리**: 해당 없음

**5.3 필터링 함수**

- **입력**: todos: Todo[], filter: FilterType
- **출력**: 필터링된 Todo[]
- **제약사항**:
  - 'all': 모든 항목
  - 'active': completed === false
  - 'completed': completed === true
- **에러 처리**: 
  - 알 수 없는 filter 값이면 'all'로 처리

**5.4 필터 상태 LocalStorage 저장**

- **입력**: filter: FilterType
- **출력**: 없음
- **제약사항**:
  - 키 이름: "todoFilter"
  - 페이지 새로고침 시 복원
- **에러 처리**: 저장 실패 시 무시

### 단계 3: 실패 기준 정의

1. **필터 변경 시 목록이 업데이트되지 않으면 실패**
   - 처리: useMemo로 todos와 filter 의존성 설정

2. **알 수 없는 필터 값으로 에러가 발생하면 실패**
   - 처리: switch 문의 default case 처리

3. **필터 상태가 페이지 새로고침 후 초기화되면 실패**
   - 처리: LocalStorage에 저장 및 로드

4. **필터링된 결과가 잘못되면 실패**
   - 처리: 각 필터 타입에 대한 정확한 조건식

### Claude Code에 제공할 프롬프트

```
할 일 필터링 기능을 구현해주세요.

[1단계: 필터 타입 정의]
src/types/index.ts에 다음을 추가해주세요:

type FilterType = 'all' | 'active' | 'completed';

export type { FilterType };

[2단계: 필터링 유틸리티]
src/utils/filter.ts 파일을 생성하고 다음을 구현해주세요:

function filterTodos(todos: Todo[], filter: FilterType): Todo[] {
  switch (filter) {
    case 'all':
      return todos;
    case 'active':
      return todos.filter(todo => !todo.completed);
    case 'completed':
      return todos.filter(todo => todo.completed);
    default:
      console.warn(`Unknown filter type: ${filter}`);
      return todos;
  }
}

[3단계: 필터 저장/로드 함수]
src/utils/storage.ts에 다음을 추가해주세요:

const FILTER_KEY = 'todoFilter';

function saveFilter(filter: FilterType): void {
  try {
    localStorage.setItem(FILTER_KEY, filter);
  } catch (error) {
    console.error('Failed to save filter:', error);
  }
}

function loadFilter(): FilterType {
  try {
    const saved = localStorage.getItem(FILTER_KEY);
    if (saved === 'all' || saved === 'active' || saved === 'completed') {
      return saved;
    }
  } catch (error) {
    console.error('Failed to load filter:', error);
  }
  return 'all'; // 기본값
}

[4단계: FilterButtons 컴포넌트]
src/components/FilterButtons.tsx 파일을 생성하고 다음을 구현해주세요:

Props:
- currentFilter: FilterType
- onFilterChange: (filter: FilterType) => void

UI:
- 3개의 버튼: "전체" / "진행중" / "완료"
- 현재 선택된 버튼은 파란색 배경
- 선택되지 않은 버튼은 회색 배경

스타일링:
- 버튼 그룹 형태 (border-radius 활용)
- 모바일 반응형
- hover 효과

버튼 매핑:
- "전체" → 'all'
- "진행중" → 'active'
- "완료" → 'completed'

[5단계: App.tsx 수정]
App.tsx를 수정하여 다음을 추가해주세요:

1. filter 상태 추가:
   - useState로 filter 상태 관리
   - 초기값은 loadFilter()로 가져오기

2. filter 변경 시 저장:
   - useEffect로 filter 변경 감지
   - saveFilter 호출

3. 필터링된 todos 계산:
   - useMemo 사용
   - filterTodos(todos, filter) 호출

4. FilterButtons 렌더링:
   - Stats와 ClearButton 사이에 배치
   - currentFilter와 onFilterChange props 전달

5. TodoList에 필터링된 todos 전달:
   - 원본 todos 대신 filteredTodos 전달

[실패 기준 - 다음 경우는 허용되지 않습니다]
1. 필터 변경 시 목록이 업데이트되지 않는 경우
2. 알 수 없는 필터 값으로 에러가 발생하는 경우
3. 필터 상태가 새로고침 후 초기화되는 경우
4. 'active' 필터에서 완료된 항목이 표시되는 경우
5. 'completed' 필터에서 미완료 항목이 표시되는 경우
6. 필터링된 결과에서 통계가 전체 todos 기준으로 표시되는 경우
```

### 검증 체크리스트

- [ ] "전체" 필터에서 모든 항목이 표시되는가?
- [ ] "진행중" 필터에서 미완료 항목만 표시되는가?
- [ ] "완료" 필터에서 완료된 항목만 표시되는가?
- [ ] 필터 변경 시 즉시 목록이 업데이트되는가?
- [ ] 현재 선택된 필터가 시각적으로 구분되는가?
- [ ] 페이지 새로고침 후에도 필터 상태가 유지되는가?
- [ ] 필터링 후에도 통계가 올바르게 표시되는가?

---

## 검증 및 테스트

### 통합 테스트 시나리오

프로젝트가 완성되면 다음 시나리오를 순서대로 테스트합니다:

#### 시나리오 1: 기본 CRUD
1. 페이지 접속
2. "운동하기" 입력 후 추가
3. "책 읽기" 입력 후 추가
4. "운동하기" 완료 체크
5. 통계 확인 (전체 2개, 완료 1개, 50%)
6. "운동하기" 삭제
7. 페이지 새로고침
8. "책 읽기"가 여전히 존재하는지 확인

#### 시나리오 2: 유효성 검증
1. 빈 문자열 입력 시도 → 버튼 비활성화 확인
2. 공백만 입력 시도 → 에러 메시지 확인
3. 201자 입력 시도 → 에러 메시지 확인
4. 정상 입력 후 Enter 키로 제출 → 입력 필드 초기화 확인

#### 시나리오 3: 필터링
1. 할 일 3개 추가
2. 그 중 2개 완료 처리
3. "진행중" 필터 선택 → 1개만 표시 확인
4. "완료" 필터 선택 → 2개만 표시 확인
5. "전체" 필터 선택 → 3개 모두 표시 확인
6. 페이지 새로고침 → 필터 상태 유지 확인

#### 시나리오 4: 일괄 삭제
1. 할 일 5개 추가
2. 그 중 3개 완료 처리
3. "완료된 항목 삭제 (3개)" 버튼 클릭
4. 확인 다이얼로그에서 확인
5. 2개만 남아있는지 확인
6. 통계 확인 (전체 2개, 완료 0개)

#### 시나리오 5: 엣지 케이스
1. 할 일을 100개 추가 → 성능 이슈 없는지 확인
2. 매우 긴 텍스트 입력 → 200자 제한 확인
3. 특수문자 포함 텍스트 입력 → 정상 저장 확인
4. LocalStorage를 수동으로 삭제 → 빈 목록으로 시작 확인
5. LocalStorage에 잘못된 JSON 입력 → 에러 없이 빈 목록으로 시작 확인

### 성능 검증

다음 항목들을 확인합니다:

- [ ] 100개 이상의 할 일이 있을 때 스크롤이 부드러운가?
- [ ] 필터 변경 시 렉이 없는가?
- [ ] 입력 시 타이핑 지연이 없는가?
- [ ] LocalStorage 저장이 UI를 블로킹하지 않는가?

### 접근성 검증

- [ ] 키보드만으로 모든 기능을 사용할 수 있는가?
- [ ] 체크박스가 키보드로 조작 가능한가?
- [ ] 버튼들이 Tab 키로 포커스 이동 가능한가?
- [ ] 스크린 리더가 각 요소를 올바르게 읽는가?

### 모바일 검증

- [ ] 모바일 화면에서 레이아웃이 깨지지 않는가?
- [ ] 터치 영역이 충분히 큰가? (최소 44x44px)
- [ ] 가로/세로 모드 전환이 정상 동작하는가?
- [ ] 가상 키보드가 나타날 때 레이아웃이 이상하지 않은가?

---

## 프로젝트 실행 방법

### 초기 설정

```bash
# 프로젝트 생성 (Claude Code에서 실행)
npm create vite@latest todo-app -- --template react-ts

# 디렉토리 이동
cd todo-app

# 의존성 설치
npm install

# Tailwind CSS 설치
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p

# 개발 서버 실행
npm run dev
```

### Claude Code에서 작업하기

1. **Claude Code 설치**
   - VS Code에서 Claude Code 익스텐션 설치
   - Anthropic API 키 설정

2. **프로젝트 열기**
   ```bash
   code todo-app
   ```

3. **Claude Code 활성화**
   - VS Code에서 Ctrl+Shift+P (Mac: Cmd+Shift+P)
   - "Claude Code: Start Chat" 선택

4. **이 문서의 프롬프트 사용**
   - 각 기능별로 제공된 프롬프트를 복사
   - Claude Code 채팅창에 붙여넣기
   - 생성된 코드 검토 및 적용

5. **반복적 개선**
   - 코드 실행 후 문제 발견 시:
     ```
     [발견된 문제]
     - 문제 설명
     - 재현 방법
     - 예상 동작 vs 실제 동작
     
     [수정 요청]
     - 구체적인 수정 방향
     ```

### 디버깅 팁

문제가 발생했을 때 Claude Code에 제공할 정보:

```
다음 문제를 해결해주세요:

[증상]
- 어떤 동작을 했을 때
- 어떤 에러가 발생했는지

[에러 메시지]
(브라우저 콘솔의 에러 메시지 전체 복사)

[관련 코드]
(문제가 발생하는 컴포넌트/함수 코드)

[기대하는 동작]
- 어떻게 동작해야 하는지

[추가 정보]
- 브라우저: Chrome 120
- 재현율: 항상 / 가끔 / 특정 조건에서만
```

---

## 추가 개선 아이디어

기본 기능이 완성되면 다음 기능들을 추가할 수 있습니다:

### 우선순위 관리
- Todo에 priority 필드 추가 (high, medium, low)
- 우선순위별 색상 표시
- 우선순위순 정렬 옵션

### 카테고리/태그
- Todo에 category 필드 추가
- 카테고리별 필터링
- 태그 관리 UI

### 검색 기능
- 텍스트 검색
- 실시간 필터링
- 검색 결과 하이라이팅

### 마감일 설정
- dueDate 필드 추가
- 날짜 선택 UI
- 마감일 임박 알림

### 편집 기능
- 기존 할 일 텍스트 수정
- 인라인 편집 UI
- 변경 내역 저장

### 데이터 내보내기/가져오기
- JSON 파일로 내보내기
- JSON 파일에서 가져오기
- CSV 형식 지원

### 다크 모드
- 다크/라이트 테마 전환
- 시스템 설정 따르기
- 테마 상태 저장

---

## 학습 포인트

이 프로젝트를 통해 배울 수 있는 것:

1. **바이브코딩 3원칙 실습**
   - 기능을 작은 단위로 쪼개는 경험
   - 명확한 요구사항 정의 연습
   - 실패 기준 우선 정의 습관

2. **AI와의 효과적인 소통**
   - 구체적인 프롬프트 작성법
   - 검증 후 피드백 제공 방법
   - 반복적 개선 프로세스

3. **TypeScript 활용**
   - 타입 안전성의 중요성
   - Interface와 Type 정의
   - 타입 가드와 타입 좁히기

4. **React 베스트 프랙티스**
   - 컴포넌트 분리 전략
   - 상태 관리 패턴
   - 성능 최적화 (useMemo, useCallback)

5. **에러 처리**
   - try-catch 활용
   - 방어적 프로그래밍
   - 사용자 친화적 에러 메시지

---

## 마치며

이 프로젝트는 바이브코딩의 핵심 원칙을 실전에 적용하는 완벽한 연습 과제입니다. 각 단계에서 제공된 프롬프트를 그대로 사용할 수도 있지만, 자신만의 방식으로 변형하고 개선하는 것을 권장합니다.

중요한 것은:
1. 항상 기능을 쪼개서 생각하기
2. 애매한 부분은 명확히 정의하기
3. 실패 케이스를 먼저 고려하기
4. AI가 생성한 코드를 반드시 검증하기
5. 문제 발견 시 구체적으로 피드백하기

이 과정을 반복하면서 AI와 협업하는 능력이 자연스럽게 향상될 것입니다.

Happy Coding! 🚀
