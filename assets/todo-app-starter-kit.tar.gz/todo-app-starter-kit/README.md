# Todo App - Vibe Coding Practice Project

A Todo management application built to demonstrate the three core principles of vibe coding: **Break it down**, **Clarify requirements**, and **Define failure criteria first**.

## 🎯 Project Purpose

This project serves as a hands-on practice for effective AI-assisted development. It's not just about building a Todo app—it's about learning how to:

1. **Break down features** into manageable pieces
2. **Write clear specifications** for AI (or any developer)
3. **Think about failure cases** before implementation
4. **Verify and iterate** on AI-generated code

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ 
- npm or yarn
- Claude Code CLI (optional but recommended)

### Installation

```bash
# Clone or create project directory
mkdir todo-app
cd todo-app

# Initialize with the provided setup
# (Follow PLAN.md Phase 1 instructions)

# Install dependencies
npm install

# Start development server
npm run dev
```

Visit `http://localhost:5173` in your browser.

## 📁 Project Structure

```
todo-app/
├── src/
│   ├── components/        # React components
│   │   ├── TodoInput.tsx
│   │   ├── TodoList.tsx
│   │   ├── TodoItem.tsx
│   │   ├── Stats.tsx
│   │   ├── FilterButtons.tsx
│   │   ├── ClearButton.tsx
│   │   └── EmptyState.tsx
│   ├── types/
│   │   └── index.ts       # TypeScript interfaces
│   ├── utils/
│   │   ├── storage.ts     # LocalStorage operations
│   │   ├── validation.ts  # Input validation
│   │   ├── filter.ts      # Filtering logic
│   │   └── dateFormat.ts  # Date formatting
│   ├── App.tsx            # Main component
│   └── main.tsx           # Entry point
├── CLAUDE.md              # Claude Code configuration
├── PLAN.md                # Implementation plan
└── README.md              # This file
```

## ✨ Features

- ✅ Add new todos with validation
- ✅ Mark todos as complete/incomplete
- ✅ Delete individual todos
- ✅ Clear all completed todos
- ✅ Filter by status (All / Active / Completed)
- ✅ View statistics (total, completed, percentage)
- ✅ Persistent storage (LocalStorage)
- ✅ Mobile-responsive design
- ✅ Keyboard navigation

## 🎓 Learning Guide

This project is designed to be built **incrementally** following the implementation plan in `PLAN.md`.

### Recommended Workflow

1. **Read the guide**: Start with `todo-app-vibe-coding-guide.md`
2. **Understand the plan**: Review `PLAN.md` 
3. **Follow phase by phase**: Don't skip ahead
4. **Use Claude Code**: Practice writing effective prompts
5. **Verify each phase**: Use the verification checklists

### Using Claude Code

```bash
# Start Claude Code in project directory
claude

# Use custom commands
/implement-feature "Add todo statistics"
/fix-bug "Empty todos not showing empty state"

# Reference the plan
@PLAN.md What should I do in Phase 3?

# Reference the configuration
@CLAUDE.md What are the coding standards?
```

## 🧪 Testing Scenarios

### Basic Flow
1. Open app → should show empty state
2. Add "운동하기" → should appear immediately
3. Refresh page → todo should persist
4. Mark as complete → should show strikethrough
5. Delete todo → should show empty state again

### Edge Cases
- Try adding empty string → should show error
- Try adding 201 characters → should show error
- Add 50 todos → should scroll smoothly
- Clear LocalStorage → should handle gracefully

## 🛠️ Development Commands

```bash
# Development
npm run dev              # Start dev server with hot reload

# Building
npm run build           # Build for production
npm run preview         # Preview production build

# Type Checking
npx tsc --noEmit        # Check TypeScript errors
```

## 📚 Tech Stack

- **React 18** - UI library
- **TypeScript** - Type safety
- **Vite** - Build tool & dev server
- **Tailwind CSS** - Styling
- **LocalStorage** - Data persistence

## 🔑 Key Concepts Demonstrated

### 1. Breaking Down Features
Every feature is split into 3-5 small, testable units:
- Data types
- Utilities
- UI components
- Integration
- Verification

### 2. Clear Requirements
Every function specifies:
- Input types and constraints
- Output format
- Error handling
- Edge cases

### 3. Failure-First Thinking
Before implementing, we define:
- What should NOT happen
- How to handle errors
- Validation rules
- User feedback

## 🤔 Common Issues & Solutions

### Issue: TypeScript errors after adding new code
**Solution**: Check that all interfaces are properly imported and types match

### Issue: Data not persisting after refresh
**Solution**: Verify LocalStorage operations in browser DevTools → Application → Local Storage

### Issue: Component not re-rendering
**Solution**: Ensure state updates use immutable operations (`[...array]` not `array.push()`)

### Issue: Tailwind classes not applying
**Solution**: Check that Tailwind is properly configured and the dev server is running

## 📖 Additional Resources

- [Vibe Coding Developer Guide](./vibe-coding-developer-guide.md) - Complete guide
- [Implementation Plan](./PLAN.md) - Step-by-step plan
- [Claude Code Docs](https://claude.com/code) - Official documentation

## 🎯 Next Steps

After completing the basic app, try:

1. **Add features**:
   - Edit existing todos
   - Add due dates
   - Priority levels
   - Categories/tags

2. **Improve code**:
   - Extract custom hooks
   - Add proper testing
   - Optimize performance
   - Improve accessibility

3. **Deploy**:
   - Deploy to Vercel/Netlify
   - Share with friends
   - Get feedback

## 📝 License

This is a learning project. Feel free to use, modify, and learn from it!

## 🙏 Acknowledgments

Built as part of vibe coding principles practice. Special thanks to the Claude Code team for creating an amazing AI-assisted development tool.

---

**Remember**: The goal isn't just to finish the app—it's to learn the *process* of effective AI-assisted development. Take your time, follow the principles, and enjoy the journey! 🚀
