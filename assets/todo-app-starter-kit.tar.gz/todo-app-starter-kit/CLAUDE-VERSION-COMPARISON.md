# CLAUDE.md 버전 비교 가이드

## 개요

이 문서는 Todo 앱 프로젝트의 두 가지 CLAUDE.md 버전을 비교하고, 각각의 장단점과 사용 시나리오를 설명합니다.

## 버전 비교

### CLAUDE.md (Original Version)
**목표:** 바이브코딩 3원칙 학습 + 일반적인 React/TypeScript 개발

### CLAUDE-v2.md (Kent Beck Style)
**목표:** TDD + Tidy First 원칙 + 바이브코딩 3원칙의 통합적 적용

---

## 핵심 차이점

### 1. 개발 방법론

**Original CLAUDE.md:**
```
접근: 단계별 프롬프트 기반 개발
순서: 요구사항 → 구현 → 검증
테스트: 선택적 (권장하지만 필수 아님)
```

**CLAUDE-v2.md (Kent Beck Style):**
```
접근: TDD 사이클 기반 개발
순서: 테스트 작성 → 구현 → 리팩토링
테스트: 필수 (모든 기능에 대해)
원칙: Red → Green → Refactor
```

### 2. 코드 변경 관리

**Original CLAUDE.md:**
```
변경 관리: 기능 단위 커밋
구조/기능: 구분 없이 함께 변경
리팩토링: 필요시 진행
```

**CLAUDE-v2.md:**
```
변경 관리: 명확히 분리된 커밋
구조/기능: 절대 섞지 않음
리팩토링: 구조 변경 → 별도 커밋 → 기능 변경
커밋 타입: [STRUCTURAL], [BEHAVIORAL], [FIX], [REFACTOR]
```

### 3. 작업 흐름

**Original CLAUDE.md:**
```
흐름:
1. 기능 쪼개기
2. 요구사항 명확화
3. 실패 기준 정의
4. 구현
5. 검증
```

**CLAUDE-v2.md:**
```
흐름:
1. 기능 쪼개기
2. 요구사항 명확화
3. 실패 기준 정의
4. 테스트 작성 (RED)
5. 최소 구현 (GREEN)
6. 구조 개선 (REFACTOR)
7. 각 단계마다 커밋
8. 반복
```

### 4. 문서 구조와 명확성

**Original CLAUDE.md:**
- 프로젝트 규칙 중심
- 일반적인 베스트 프랙티스
- 예시 코드 포함
- 체크리스트 형식

**CLAUDE-v2.md:**
- 방법론 중심 (TDD + Tidy First)
- 구체적인 워크플로우 정의
- 실제 예시와 안티패턴
- 단계별 가이드

---

## 상세 비교표

| 측면 | Original | Kent Beck Style |
|------|----------|-----------------|
| **학습 곡선** | 낮음 (바로 시작 가능) | 중간 (TDD 개념 필요) |
| **테스트 작성** | 선택적 | 필수 (테스트 우선) |
| **커밋 규칙** | 유연함 | 엄격함 (구조/기능 분리) |
| **리팩토링** | 필요시 | 매 사이클마다 |
| **문서 길이** | 약 7KB | 약 12KB |
| **초보자 친화성** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |
| **전문성** | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **유지보수성** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **코드 품질** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |

---

## 각 버전의 장단점

### Original CLAUDE.md

**장점:**
- ✅ 바로 시작할 수 있음
- ✅ 학습 곡선이 낮음
- ✅ 유연한 개발 가능
- ✅ 초보자에게 부담 없음
- ✅ 빠른 프로토타이핑 가능

**단점:**
- ❌ 테스트 작성이 선택적
- ❌ 리팩토링 시점이 불명확
- ❌ 구조/기능 변경이 섞일 수 있음
- ❌ 커밋 히스토리가 덜 체계적
- ❌ 장기적 품질 관리 어려움

**적합한 경우:**
- 🎯 바이브코딩을 처음 배우는 경우
- 🎯 빠른 프로토타입이 필요한 경우
- 🎯 개인 학습 프로젝트
- 🎯 TDD에 익숙하지 않은 경우

### CLAUDE-v2.md (Kent Beck Style)

**장점:**
- ✅ 높은 코드 품질 보장
- ✅ 체계적인 테스트 커버리지
- ✅ 명확한 커밋 히스토리
- ✅ 리팩토링 안전성
- ✅ 전문적인 개발 프로세스
- ✅ 장기적 유지보수 용이

**단점:**
- ❌ 초기 학습 비용이 높음
- ❌ 테스트 작성 시간 필요
- ❌ 엄격한 규칙 준수 필요
- ❌ 빠른 프로토타이핑에 부적합
- ❌ 초보자에게 부담될 수 있음

**적합한 경우:**
- 🎯 TDD를 배우고 싶은 경우
- 🎯 프로덕션급 코드 작성
- 🎯 팀 프로젝트 (일관성 중요)
- 🎯 장기 유지보수 프로젝트
- 🎯 전문적인 개발 프로세스 구축

---

## 사용 시나리오별 추천

### 시나리오 1: 완전 초보 개발자
**추천:** Original CLAUDE.md
**이유:**
- 바이브코딩 3원칙만 집중
- TDD 부담 없이 시작
- 빠른 피드백 루프
- 점진적 학습 가능

### 시나리오 2: 주니어 개발자 (1-2년 경험)
**추천:** Original → Kent Beck Style 전환
**이유:**
- 먼저 Original로 빠르게 완성
- 그 다음 Kent Beck Style로 리팩토링
- 두 가지 접근법 비교 학습

### 시나리오 3: 중급 개발자 (3-5년 경험)
**추천:** CLAUDE-v2.md (Kent Beck Style)
**이유:**
- TDD 개념 이해 가능
- 전문적인 프로세스 학습
- 고품질 코드 작성 연습
- 실무 적용 준비

### 시나리오 4: 시니어 개발자
**추천:** CLAUDE-v2.md + 커스터마이징
**이유:**
- 자신의 철학과 통합
- 팀 표준 수립
- 멘토링 자료로 활용

### 시나리오 5: 빠른 프로토타입 필요
**추천:** Original CLAUDE.md
**이유:**
- 최소한의 제약
- 빠른 반복
- 나중에 리팩토링

### 시나리오 6: 프로덕션 프로젝트
**추천:** CLAUDE-v2.md (Kent Beck Style)
**이유:**
- 높은 품질 보장
- 체계적인 테스트
- 유지보수성
- 팀 협업 용이

---

## 실전 적용 전략

### 전략 1: 순차 학습 (권장)

**1단계: Original CLAUDE.md로 빠른 완성**
```bash
목표: 기능 구현과 바이브코딩 3원칙 이해
기간: 1-2주
산출물: 동작하는 Todo 앱
```

**2단계: 테스트 추가**
```bash
목표: 기존 코드에 테스트 작성
기간: 1주
산출물: 테스트 커버리지 50%+
```

**3단계: Kent Beck Style로 전환**
```bash
목표: CLAUDE-v2.md 적용, TDD 사이클 연습
기간: 1-2주
산출물: 리팩토링된 고품질 코드
```

### 전략 2: 하이브리드 (중급자 이상)

**개발 초기:** Original CLAUDE.md의 유연성
```
- 빠른 기능 구현
- 아이디어 검증
- UI/UX 실험
```

**개발 중기:** Kent Beck Style로 전환
```
- 핵심 기능 확정 후
- 테스트 추가
- 구조 개선
```

**개발 후기:** 엄격한 TDD 적용
```
- 버그 수정 시
- 새 기능 추가 시
- 리팩토링 시
```

### 전략 3: 상황별 선택

**프로토타입/POC:**
- Original CLAUDE.md
- 빠른 검증 우선

**MVP 개발:**
- 하이브리드 접근
- 핵심만 Kent Beck Style

**프로덕션:**
- CLAUDE-v2.md
- 전체 TDD 적용

---

## 코드 예시 비교

### 예시: Todo 추가 기능 구현

#### Original CLAUDE.md 방식:

```typescript
// 1. 요구사항 정의
// 2. 구현
// 3. 검증

// components/TodoInput.tsx
function TodoInput({ onAdd }: TodoInputProps) {
  const [text, setText] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = () => {
    const validation = validateTodoText(text);
    if (!validation.isValid) {
      setError(validation.errorMessage!);
      return;
    }
    onAdd(text);
    setText('');
    setError('');
  };

  return (
    <div>
      <input value={text} onChange={e => setText(e.target.value)} />
      <button onClick={handleSubmit}>추가</button>
      {error && <p>{error}</p>}
    </div>
  );
}
```

**특징:**
- 바로 구현
- 테스트 선택적
- 한 번에 완성

#### CLAUDE-v2.md (Kent Beck Style) 방식:

```typescript
// Step 1: RED - 테스트 작성
describe('TodoInput', () => {
  it('should reject empty todo text', () => {
    const onAdd = jest.fn();
    render(<TodoInput onAdd={onAdd} />);
    
    const button = screen.getByRole('button');
    fireEvent.click(button);
    
    expect(onAdd).not.toHaveBeenCalled();
    expect(screen.getByText('할 일을 입력해주세요')).toBeInTheDocument();
  });
});

// Step 2: GREEN - 최소 구현
function TodoInput({ onAdd }: TodoInputProps) {
  const [text, setText] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = () => {
    if (text.trim() === '') {
      setError('할 일을 입력해주세요');
      return;
    }
    onAdd(text);
    setText('');
    setError('');
  };

  return (
    <div>
      <input value={text} onChange={e => setText(e.target.value)} />
      <button onClick={handleSubmit}>추가</button>
      {error && <p>{error}</p>}
    </div>
  );
}

// Step 3: REFACTOR - 검증 로직 추출
// [STRUCTURAL] 커밋
function TodoInput({ onAdd }: TodoInputProps) {
  const [text, setText] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = () => {
    const validation = validateTodoText(text);
    if (!validation.isValid) {
      setError(validation.errorMessage!);
      return;
    }
    onAdd(text);
    setText('');
    setError('');
  };

  // ... rest of component
}

// [BEHAVIORAL] 커밋: Add todo input with validation
```

**특징:**
- 테스트 먼저
- 단계적 구현
- 구조/기능 분리
- 명확한 커밋 히스토리

---

## 마이그레이션 가이드

### Original → Kent Beck Style로 전환

**Step 1: 테스트 인프라 설정**
```bash
npm install --save-dev jest @testing-library/react @testing-library/jest-dom
npm install --save-dev @testing-library/user-event
```

**Step 2: 기존 코드에 테스트 추가**
```typescript
// 컴포넌트별로 하나씩
describe('TodoList', () => {
  it('should render empty state when no todos', () => {
    // 기존 동작 테스트
  });
});
```

**Step 3: CLAUDE-v2.md 적용**
```bash
# 기존 CLAUDE.md를 백업
mv CLAUDE.md CLAUDE-original.md

# Kent Beck Style 적용
mv CLAUDE-v2.md CLAUDE.md

# Claude Code 재시작
claude
```

**Step 4: 새 기능은 TDD로**
```
- 기존 코드: 테스트 추가하며 유지
- 새 기능: Red-Green-Refactor 사이클 적용
- 리팩토링: 구조/기능 엄격히 분리
```

---

## FAQ

### Q1: 어떤 버전을 선택해야 하나요?
**A:** 경험 수준과 프로젝트 목표에 따라 다릅니다:
- 초보자 + 학습 목적 → Original
- 중급자 + 실무 적용 → Kent Beck Style
- 프로토타입 → Original
- 프로덕션 → Kent Beck Style

### Q2: 두 버전을 함께 사용할 수 있나요?
**A:** 아니요. Claude Code는 하나의 CLAUDE.md만 읽습니다. 하지만:
- 프로젝트 단계별로 전환 가능
- 서로 다른 프로젝트에 각각 적용 가능

### Q3: Kent Beck Style이 더 좋은가요?
**A:** "더 좋다"보다는 "더 엄격하다"가 정확합니다:
- 코드 품질: Kent Beck Style이 우수
- 학습 용이성: Original이 우수
- 선택은 상황에 따라

### Q4: TDD를 모르면 Kent Beck Style을 못 쓰나요?
**A:** 권장하지 않습니다. 하지만:
- 이 프로젝트로 TDD를 배울 수 있음
- CLAUDE.md가 매 단계 가이드
- 점진적 학습 가능

### Q5: 실무에서는 어떤 것을 쓰나요?
**A:** 팀과 상황에 따라 다릅니다:
- 스타트업 초기: Original (속도 우선)
- 확장 단계: Kent Beck Style (품질 우선)
- 엔터프라이즈: Kent Beck Style (유지보수)

---

## 결론

### Original CLAUDE.md를 선택하세요:
- ✅ 바이브코딩을 처음 배울 때
- ✅ 빠른 프로토타이핑이 필요할 때
- ✅ 개인 학습 프로젝트일 때
- ✅ TDD 경험이 없을 때

### CLAUDE-v2.md (Kent Beck Style)를 선택하세요:
- ✅ 전문적인 개발 프로세스를 배우고 싶을 때
- ✅ 프로덕션급 코드를 작성할 때
- ✅ 팀 프로젝트일 때
- ✅ 장기 유지보수가 중요할 때

### 가장 좋은 방법:
**순차적으로 두 버전 모두 경험하기**
1. Original로 빠르게 완성
2. 동작 확인 및 학습
3. Kent Beck Style로 리팩토링
4. 두 접근법의 차이 체감
5. 상황에 맞는 선택 가능

---

**Remember:** 도구는 목적에 맞게 선택하는 것이 중요합니다. 두 버전 모두 훌륭한 가이드이며, 여러분의 상황과 목표에 맞는 것을 선택하세요! 🚀
