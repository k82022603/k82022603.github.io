# Todo App Starter Kit - 파일 목록 (Updated)

## 📦 전체 구성

```
todo-app-starter-kit/
├── 📘 GETTING-STARTED.md              ⭐ START HERE! 시작 가이드
├── 📕 CLAUDE.md                       ⭐ Original - 바이브코딩 중심
├── 🔥 CLAUDE-v2.md                    ⭐ NEW! Kent Beck TDD 스타일
├── 📊 CLAUDE-VERSION-COMPARISON.md    🆕 두 버전 비교 가이드
├── 📗 PLAN.md                         ⭐ 7단계 구현 계획
├── 📙 README.md                       프로젝트 소개
├── 📔 todo-app-vibe-coding-guide.md   상세 구현 가이드
├── 📄 FILE-MANIFEST.md                (이 파일) 파일 목록
└── .claude/
    └── commands/
        ├── implement-feature.md       슬래시 커맨드: 기능 구현
        └── fix-bug.md                 슬래시 커맨드: 버그 수정
```

## 🆕 새로 추가된 파일

### CLAUDE-v2.md (Kent Beck Style)
- **목적**: TDD + Tidy First 원칙을 적용한 전문가용 CLAUDE.md
- **특징**:
  - Red-Green-Refactor 사이클 강제
  - 구조/기능 변경 엄격히 분리
  - 테스트 우선 개발
  - 명확한 커밋 규칙
- **누구에게**: TDD를 배우고 싶거나 프로덕션급 코드 작성 시

### CLAUDE-VERSION-COMPARISON.md
- **목적**: 두 CLAUDE.md 버전의 차이점과 선택 가이드
- **포함 내용**:
  - 상세 비교표
  - 장단점 분석
  - 시나리오별 추천
  - 마이그레이션 가이드
  - 실전 적용 전략
  - FAQ

## 📖 읽기 순서

### 처음 시작하는 경우
1. **GETTING-STARTED.md** (필수)
2. **CLAUDE-VERSION-COMPARISON.md** (어떤 버전을 쓸지 결정)
3. 선택한 버전의 CLAUDE.md 읽기
4. **PLAN.md** 따라 구현

### 두 버전 모두 경험하고 싶은 경우
1. **GETTING-STARTED.md** 
2. **CLAUDE.md** (Original) 사용해서 완성
3. **CLAUDE-VERSION-COMPARISON.md** 읽고 차이 이해
4. **CLAUDE-v2.md**로 전환해서 리팩토링
5. 두 접근법 비교 학습

## 🎯 각 파일의 역할

| 파일 | 역할 | 대상 | 난이도 |
|------|------|------|--------|
| GETTING-STARTED.md | 종합 시작 가이드 | 모두 | ⭐ |
| CLAUDE.md | 바이브코딩 중심 설정 | 초보~중급 | ⭐⭐ |
| CLAUDE-v2.md | TDD+Tidy First 설정 | 중급~고급 | ⭐⭐⭐⭐ |
| CLAUDE-VERSION-COMPARISON.md | 두 버전 비교 | 모두 | ⭐⭐ |
| PLAN.md | 구현 로드맵 | 모두 | ⭐⭐ |
| README.md | 프로젝트 소개 | 모두 | ⭐ |
| todo-app-vibe-coding-guide.md | 상세 교과서 | 모두 | ⭐⭐⭐ |
| implement-feature.md | 기능 구현 템플릿 | 모두 | ⭐⭐ |
| fix-bug.md | 버그 수정 템플릿 | 모두 | ⭐⭐ |

## 🚀 빠른 시작 - 버전별

### Original CLAUDE.md로 시작 (초보자 권장)

```bash
# 1. 압축 해제 및 이동
tar -xzf todo-app-starter-kit.tar.gz
cd todo-app-starter-kit

# 2. CLAUDE.md 확인 (이미 Original 버전)
cat CLAUDE.md

# 3. Claude Code 시작
claude

# 4. 첫 명령
claude> @PLAN.md Phase 1의 프롬프트대로 프로젝트를 설정해줘.
```

### CLAUDE-v2.md로 시작 (TDD 학습/전문가)

```bash
# 1. 압축 해제 및 이동
tar -xzf todo-app-starter-kit.tar.gz
cd todo-app-starter-kit

# 2. Kent Beck 스타일로 전환
mv CLAUDE.md CLAUDE-original.md
mv CLAUDE-v2.md CLAUDE.md

# 3. Claude Code 시작
claude

# 4. 첫 명령 (TDD 방식)
claude> @PLAN.md Phase 1을 TDD 사이클로 진행해줘. 먼저 테스트부터.
```

## 📊 버전 선택 가이드 (간단 버전)

### CLAUDE.md (Original) 선택:
- ✅ 처음 바이브코딩 배우는 경우
- ✅ 빠른 프로토타입 필요
- ✅ TDD 경험 없음
- ✅ 개인 학습 프로젝트

### CLAUDE-v2.md (Kent Beck) 선택:
- ✅ TDD 배우고 싶음
- ✅ 프로덕션급 코드 작성
- ✅ 팀 프로젝트
- ✅ 장기 유지보수 중요

**모르겠다면?** → GETTING-STARTED.md 읽고 → CLAUDE-VERSION-COMPARISON.md 참고

## 🔄 버전 전환 방법

### Original → Kent Beck Style
```bash
# 백업
mv CLAUDE.md CLAUDE-original.md

# 전환
cp CLAUDE-v2.md CLAUDE.md

# Claude Code 재시작
claude
```

### Kent Beck → Original Style
```bash
# 백업
mv CLAUDE.md CLAUDE-v2-backup.md

# 전환
cp CLAUDE-original.md CLAUDE.md

# Claude Code 재시작
claude
```

## ⚠️ 주의사항

1. **한 번에 하나의 CLAUDE.md만 사용**
   - Claude Code는 `CLAUDE.md` 파일 하나만 읽음
   - 다른 버전은 다른 이름으로 백업

2. **.claude 폴더 확인**
   - 숨김 폴더이므로 `ls -la`로 확인
   - 복사 시 포함되도록 주의

3. **버전 선택 전 비교 문서 읽기**
   - CLAUDE-VERSION-COMPARISON.md 필독
   - 자신의 수준과 목표에 맞는 선택

4. **두 버전 모두 체험 권장**
   - Original로 빠르게 완성
   - Kent Beck Style로 리팩토링
   - 차이를 직접 경험

## 📝 체크리스트

프로젝트 시작 전:
- [ ] 모든 파일이 있는지 확인
- [ ] .claude 폴더가 있는지 확인
- [ ] GETTING-STARTED.md 읽음
- [ ] CLAUDE-VERSION-COMPARISON.md 읽음
- [ ] 사용할 CLAUDE.md 버전 결정
- [ ] Claude Code 설치 완료
- [ ] Node.js 설치 완료

## 🆘 문제 해결

**Q: 어떤 버전을 써야 할지 모르겠어요**
→ A: CLAUDE-VERSION-COMPARISON.md 읽고 결정

**Q: 파일이 안 보여요**
→ A: `ls -la`로 숨김 파일 확인

**Q: Claude가 규칙을 안 따라요**
→ A: CLAUDE.md가 프로젝트 루트에 있는지 확인

**Q: 두 버전을 번갈아 쓸 수 있나요?**
→ A: 네! 위의 "버전 전환 방법" 참고

**Q: Kent Beck Style이 너무 어려워요**
→ A: Original로 시작하세요. 나중에 전환 가능

## 🎓 학습 경로 추천

### 경로 1: 안전한 학습 (초보자)
```
1. Original CLAUDE.md → PLAN.md 따라 완성
2. 동작하는 앱 확인
3. CLAUDE-VERSION-COMPARISON.md 읽기
4. Kent Beck Style로 전환
5. 같은 앱을 리팩토링
6. 두 방식 비교
```

### 경로 2: 직접 도전 (중급자)
```
1. CLAUDE-VERSION-COMPARISON.md 읽기
2. Kent Beck Style 선택
3. TDD로 처음부터 구현
4. 완성 후 Original 방식도 체험
```

### 경로 3: 실무 적용 (고급자)
```
1. Kent Beck Style로 시작
2. 프로젝트에 맞게 커스터마이징
3. 팀 표준으로 채택
4. 멘토링 자료로 활용
```

---

## 🎉 시작 준비 완료!

**다음 단계:**
1. GETTING-STARTED.md 열기
2. 사용할 CLAUDE.md 버전 결정
3. PLAN.md 따라 개발 시작

**Happy Coding!** 🚀
