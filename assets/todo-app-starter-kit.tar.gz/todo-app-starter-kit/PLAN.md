# Todo App - Implementation Plan

## 📋 Project Overview

**Goal**: Build a Todo management app that demonstrates vibe coding principles  
**Timeline**: 4-6 hours of development time  
**Approach**: Incremental development with continuous verification

## 🎯 Success Criteria

By the end of this project, you will have:
- ✅ A fully functional Todo app
- ✅ All features working correctly
- ✅ Data persisting in LocalStorage
- ✅ Mobile-responsive design
- ✅ Proper error handling
- ✅ TypeScript type safety throughout

## 📝 Implementation Phases

### Phase 1: Project Setup (Est. 30 minutes)

**Tasks:**
1. Initialize Vite + React + TypeScript project
2. Configure Tailwind CSS
3. Set up project structure (folders)
4. Create CLAUDE.md file
5. Verify dev server runs

**Verification:**
- [ ] `npm run dev` works without errors
- [ ] Tailwind classes apply correctly
- [ ] TypeScript compiles without errors
- [ ] Browser shows "Todo App" title

**Prompt for Claude Code:**
```
I'm starting a new Todo app project. Please follow the setup instructions in the project guide document.

Create:
1. Vite + React + TypeScript project structure
2. Tailwind CSS configuration
3. Basic folder structure (components, types, hooks, utils)
4. Minimal App.tsx with "Todo App" heading

Requirements:
- Use Vite (not Create React App)
- TypeScript strict mode
- Tailwind CSS for all styling
- No external UI libraries

Verify everything compiles and the dev server runs.
```

---

### Phase 2: Data Layer (Est. 45 minutes)

**Tasks:**
1. Define Todo type in `types/index.ts`
2. Create `utils/storage.ts` for LocalStorage operations
3. Create `utils/validation.ts` for input validation
4. Test each utility function

**Verification:**
- [ ] Todo interface has all required fields
- [ ] saveTodos/loadTodos handle errors gracefully
- [ ] validateTodoText catches all invalid inputs
- [ ] TypeScript types are correct

**Prompt for Claude Code:**
```
Implement the data layer for the Todo app.

Create three files:

1. src/types/index.ts
   - Todo interface with: id, text, completed, createdAt
   - Export the interface

2. src/utils/storage.ts
   - saveTodos(todos: Todo[]): void
   - loadTodos(): Todo[]
   - Handle JSON parsing errors
   - Handle Date deserialization
   - Use try-catch for all operations

3. src/utils/validation.ts
   - validateTodoText(text: string): { isValid: boolean; errorMessage?: string }
   - Check: empty string, whitespace only, 200 char limit
   - Return specific error messages

Follow the three principles:
- Break down each utility into clear functions
- Define input/output types explicitly
- Handle all failure cases (JSON parse errors, invalid data, etc.)

Add JSDoc comments to all functions.
```

---

### Phase 3: Add Todo Feature (Est. 60 minutes)

**Tasks:**
1. Create TodoInput component
2. Implement add todo logic in App.tsx
3. Wire up LocalStorage saving
4. Test all validation scenarios

**Verification:**
- [ ] Cannot submit empty string
- [ ] Cannot submit whitespace only
- [ ] Cannot submit 201+ characters
- [ ] Input clears after submit
- [ ] Enter key works
- [ ] Data persists after refresh

**Prompt for Claude Code:**
```
Implement the "Add Todo" feature.

Create TodoInput component (src/components/TodoInput.tsx):

Props:
- onAdd: (text: string) => void

Behavior:
- Text input + Add button
- Real-time validation using validateTodoText
- Show error message if invalid
- Disable button when invalid
- Clear input after successful add
- Support Enter key submission

Styling:
- Use Tailwind CSS
- Mobile-friendly (44px+ touch targets)
- Error messages in red below input

Then update App.tsx:
- Add todos state (useState<Todo[]>)
- Implement handleAddTodo function
- Use crypto.randomUUID() for id (fallback to Date.now())
- Save to LocalStorage on every change
- Load from LocalStorage on mount

Failure cases to handle:
- Empty string submission attempt
- Whitespace-only submission
- 201+ character input
- LocalStorage quota exceeded
- Page refresh (data must persist)

Test by adding several todos, then refreshing the page.
```

---

### Phase 4: Display Todo List (Est. 45 minutes)

**Tasks:**
1. Create TodoList component
2. Create TodoItem component
3. Create EmptyState component
4. Implement date formatting utility

**Verification:**
- [ ] Empty state shows when no todos
- [ ] Todos display in reverse chronological order
- [ ] Completed todos have visual distinction
- [ ] Relative time displays correctly
- [ ] Mobile responsive layout

**Prompt for Claude Code:**
```
Implement the Todo list display.

Create four components:

1. src/utils/dateFormat.ts
   - formatRelativeTime(date: Date): string
   - Returns: "방금 전", "5분 전", "2시간 전", "3일 전"

2. src/components/TodoItem.tsx
   Props: todo, onToggle, onDelete
   Layout: [checkbox] [text] [time] [delete button]
   - Completed: line-through + gray color
   - Mobile-friendly touch targets

3. src/components/EmptyState.tsx
   - Show when todos array is empty
   - Display message + icon
   - Center aligned, gray text

4. src/components/TodoList.tsx
   Props: todos, onToggle, onDelete
   - Sort by createdAt descending (newest first)
   - Map to TodoItem components
   - Show EmptyState if empty

Update App.tsx:
- Add handleToggleTodo(id: string)
- Add handleDeleteTodo(id: string)
- Render TodoList below TodoInput

Failure cases:
- todos is undefined → treat as empty array
- todo is null → skip rendering
- createdAt is invalid → show "알 수 없음"

Use Tailwind for all styling.
```

---

### Phase 5: Statistics & Clear Completed (Est. 30 minutes)

**Tasks:**
1. Create Stats component
2. Create ClearButton component
3. Implement clear completed logic

**Verification:**
- [ ] Stats show correct counts
- [ ] Percentage calculates correctly
- [ ] Progress bar displays proportionally
- [ ] Clear button only shows when there are completed items
- [ ] Confirm dialog appears before clearing

**Prompt for Claude Code:**
```
Add statistics and bulk delete features.

Create two components:

1. src/components/Stats.tsx
   Props: total: number, completed: number
   Display:
   - "전체 X개 / 완료 Y개 (Z%)"
   - Progress bar (0-100%)
   - Handle division by zero (total = 0)

2. src/components/ClearButton.tsx
   Props: completedCount: number, onClick: () => void
   - Text: "완료된 항목 삭제 (X개)"
   - Disabled when completedCount = 0
   - Red/destructive styling

Update App.tsx:
- Calculate total and completed from todos
- Add handleClearCompleted function
  - Show confirm dialog
  - Filter out completed todos
- Render in order: TodoInput → Stats → ClearButton → TodoList

Failure cases:
- total = 0 → percentage should be 0%
- No completed items → button disabled
- User cancels confirm → no deletion
```

---

### Phase 6: Filtering (Est. 45 minutes)

**Tasks:**
1. Add FilterType to types
2. Create filter utility function
3. Create FilterButtons component
4. Implement filter persistence

**Verification:**
- [ ] "전체" shows all todos
- [ ] "진행중" shows only incomplete
- [ ] "완료" shows only completed
- [ ] Active filter is visually highlighted
- [ ] Filter persists after refresh

**Prompt for Claude Code:**
```
Implement filtering functionality.

1. Add to src/types/index.ts:
   - type FilterType = 'all' | 'active' | 'completed'

2. Create src/utils/filter.ts:
   - filterTodos(todos: Todo[], filter: FilterType): Todo[]
   - Handle unknown filter (default to 'all')

3. Update src/utils/storage.ts:
   - saveFilter(filter: FilterType): void
   - loadFilter(): FilterType (default 'all')

4. Create src/components/FilterButtons.tsx:
   Props: currentFilter, onFilterChange
   - Three buttons: 전체 / 진행중 / 완료
   - Highlight active filter (blue background)
   - Button group styling

Update App.tsx:
- Add filter state
- Load filter on mount
- Save filter on change
- Calculate filteredTodos using useMemo
- Pass filteredTodos to TodoList
- Render FilterButtons between Stats and TodoList

Verify:
- Switching filters updates list immediately
- Filter persists after page refresh
- Stats still show total numbers (not filtered)
```

---

### Phase 7: Final Polish & Testing (Est. 45 minutes)

**Tasks:**
1. Add delete confirmation dialogs
2. Improve error messages
3. Test all features thoroughly
4. Fix any bugs found
5. Add loading states if needed

**Verification Checklist:**

**Functionality:**
- [ ] Can add new todos
- [ ] Can toggle completion
- [ ] Can delete individual todos
- [ ] Can clear all completed
- [ ] Can filter by status
- [ ] Data persists across refreshes

**Validation:**
- [ ] Cannot submit empty todo
- [ ] Cannot submit whitespace-only
- [ ] Cannot submit 201+ characters
- [ ] Error messages are clear

**UI/UX:**
- [ ] Mobile responsive (test at 375px width)
- [ ] Touch targets are adequate (44px+)
- [ ] Loading states during actions
- [ ] Confirm destructive actions

**Accessibility:**
- [ ] Keyboard navigation works
- [ ] Focus indicators visible
- [ ] Semantic HTML used

**Edge Cases:**
- [ ] Handles 0 todos
- [ ] Handles 100+ todos
- [ ] Handles LocalStorage errors
- [ ] Handles invalid stored data

**Prompt for Claude Code:**
```
Perform final testing and polish.

1. Add confirm dialogs:
   - Individual delete: "정말 삭제하시겠습니까?"
   - Clear completed: "완료된 X개의 할 일을 삭제하시겠습니까?"

2. Improve error handling:
   - LocalStorage quota exceeded → show user alert
   - JSON parse error → log warning, return empty array

3. Test the entire app:
   - Run through all features
   - Test edge cases (0 todos, 100+ todos)
   - Test mobile view
   - Test keyboard navigation

4. Fix any issues found

Create a simple test document listing:
- What was tested
- What works correctly
- Any known limitations
```

---

## 🔍 Testing Scenarios

Run through these scenarios to verify everything works:

### Scenario 1: First Time User
1. Open app (should show empty state)
2. Try to add empty todo (should show error)
3. Add "운동하기" (should appear in list)
4. Refresh page (should still be there)

### Scenario 2: Power User
1. Add 5 todos quickly
2. Complete 3 of them
3. Check statistics (should show 5 total, 3 completed, 60%)
4. Filter to "진행중" (should show 2)
5. Clear completed (should remove 3)
6. Refresh (should have 2 todos, "전체" filter active)

### Scenario 3: Edge Cases
1. Try to add 201-character todo
2. Add todo with special characters: "🎉 Test ™️ <script>"
3. Rapidly toggle same todo 10 times
4. Clear browser's LocalStorage manually, then reload
5. Add 50 todos, scroll through list

## 📦 Deliverables Checklist

- [ ] Working Todo app accessible in browser
- [ ] All source code in proper folder structure
- [ ] CLAUDE.md file with project context
- [ ] README.md with setup instructions
- [ ] No TypeScript errors
- [ ] No console errors in browser
- [ ] Mobile responsive design
- [ ] All features work as specified

## 🎓 Learning Outcomes

After completing this project, you will understand:

1. **Breaking Down Features**
   - How to split large features into small tasks
   - Planning before coding

2. **Clarifying Requirements**
   - Writing clear function specifications
   - Defining inputs, outputs, constraints

3. **Defining Failure Cases**
   - Thinking about edge cases first
   - Proper error handling

4. **Working with AI**
   - Writing effective prompts
   - Verifying AI-generated code
   - Iterative improvement

5. **React + TypeScript Best Practices**
   - Component composition
   - State management
   - Type safety

## 🚀 Next Steps

After completing the basic app:

1. **Add Advanced Features:**
   - Todo editing
   - Due dates
   - Priority levels
   - Categories/tags
   - Search functionality

2. **Improve Performance:**
   - Add React.memo where needed
   - Optimize re-renders
   - Lazy load components

3. **Add Testing:**
   - Unit tests for utilities
   - Component tests
   - Integration tests

4. **Deploy:**
   - Deploy to Vercel
   - Add custom domain
   - Set up analytics

## 💬 Getting Help

If you get stuck:

1. **Read error messages carefully** - They usually tell you what's wrong
2. **Check CLAUDE.md** - See if there's guidance for your issue
3. **Ask Claude Code** - Be specific about the problem
4. **Test incrementally** - Don't add multiple features at once

Remember: The goal is learning the process, not just finishing the project!
