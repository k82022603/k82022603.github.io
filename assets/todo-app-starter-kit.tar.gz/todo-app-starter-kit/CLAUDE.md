# Todo App - Project Configuration

## 🚨 CRITICAL RULES

**Before making ANY code changes:**
1. Apply the three principles: Break down → Clarify requirements → Define failure criteria
2. Understand the full context by reading related files
3. Create a plan and get confirmation before implementing
4. Write tests for critical functionality
5. Always maintain TypeScript type safety

**Code Quality Standards:**
- All functions must have JSDoc comments
- Use TypeScript strict mode
- Handle all error cases explicitly
- No console.log in production code (use proper error handling)
- Maintain immutability in state updates

**Testing Requirements:**
- Write tests before implementing complex logic
- Test happy path, edge cases, and error cases
- Ensure all tests pass before committing

## 🎯 PROJECT CONTEXT

**Tech Stack:**
- React 18 + TypeScript
- Vite for build tooling
- Tailwind CSS for styling
- LocalStorage for data persistence

**Project Structure:**
```
src/
  components/     # React components (one component per file)
  types/          # TypeScript interfaces and types
  hooks/          # Custom React hooks
  utils/          # Helper functions (validation, storage, formatting)
  App.tsx         # Main app component
  main.tsx        # Entry point
```

**Key Design Decisions:**
- Component-based architecture (small, focused components)
- LocalStorage for persistence (no backend required)
- Mobile-first responsive design
- Accessibility-focused (keyboard navigation, ARIA labels)

## 🔧 DEVELOPMENT PATTERNS

**Component Guidelines:**
- One component per file
- Props interface defined in the same file
- Keep components small and focused (< 150 lines)
- Use functional components with hooks
- Extract complex logic into custom hooks

**State Management:**
- Use useState for local state
- Use useEffect for side effects (LocalStorage sync)
- Use useMemo for expensive computations
- Maintain immutability: use map/filter instead of push/splice

**File Naming:**
- Components: PascalCase (e.g., TodoItem.tsx)
- Utilities: camelCase (e.g., validation.ts)
- Types: index.ts in types folder
- Hooks: use prefix "use" (e.g., useTodos.ts)

**TypeScript Best Practices:**
- Define all interfaces explicitly
- Use type guards for runtime checks
- Avoid `any` type (use `unknown` if necessary)
- Export types that are used in multiple files

**Import Order:**
1. React imports
2. Third-party libraries
3. Local components
4. Types
5. Utilities
6. Styles (if any)

## 📝 CODING WORKFLOW

**For New Features:**
1. **Break Down** the feature into 3-5 small tasks
2. **Clarify** requirements:
   - Define input/output for each function
   - List all constraints
   - Specify error handling
3. **Define Failure Criteria**:
   - List what should NOT happen
   - Define error cases and handling
4. **Implement** incrementally (one task at a time)
5. **Test** each task before moving to next
6. **Review** code for type safety and error handling

**For Bug Fixes:**
1. Reproduce the bug
2. Identify root cause
3. Write a test that fails
4. Fix the bug
5. Verify the test passes
6. Check for similar bugs elsewhere

**For Refactoring:**
1. Ensure tests exist and pass
2. Make one change at a time
3. Run tests after each change
4. Verify functionality is preserved

## 🛠️ DEVELOPMENT COMMANDS

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Type check
npx tsc --noEmit

# Lint (if configured)
npm run lint
```

## ⚠️ COMMON PITFALLS TO AVOID

**State Management:**
- ❌ Mutating state directly: `todos.push(newTodo)`
- ✅ Creating new arrays: `[...todos, newTodo]`

**LocalStorage:**
- ❌ Not handling JSON parse errors
- ✅ Always use try-catch when parsing
- ❌ Storing Date objects directly
- ✅ Convert to ISO string and back

**Event Handlers:**
- ❌ Inline arrow functions: `onClick={() => handler()}`
- ✅ Pass function reference or use useCallback

**TypeScript:**
- ❌ Using `any` type
- ✅ Define proper interfaces or use `unknown`
- ❌ Ignoring type errors with `@ts-ignore`
- ✅ Fix the underlying type issue

## 🧪 TESTING GUIDELINES

**What to Test:**
- All validation functions
- LocalStorage operations
- State update logic
- Edge cases (empty arrays, null values, etc.)
- Error handling paths

**Test Structure:**
```typescript
describe('Component/Function Name', () => {
  describe('Success Cases', () => {
    it('should handle normal input', () => {
      // test
    });
  });
  
  describe('Edge Cases', () => {
    it('should handle empty input', () => {
      // test
    });
  });
  
  describe('Error Cases', () => {
    it('should handle invalid input', () => {
      // test
    });
  });
});
```

## 🎨 UI/UX STANDARDS

**Responsive Design:**
- Mobile-first approach
- Touch targets minimum 44x44px
- Test on mobile viewport (375px width)
- Ensure horizontal scrolling is never needed

**Accessibility:**
- All interactive elements must be keyboard accessible
- Use semantic HTML (button, input, etc.)
- Provide ARIA labels where needed
- Maintain sufficient color contrast

**User Feedback:**
- Show loading states during operations
- Display error messages clearly
- Confirm destructive actions (delete, clear)
- Show success indicators after actions

## 🔒 SECURITY CONSIDERATIONS

- Never store sensitive data in LocalStorage
- Sanitize user input (though XSS risk is low with React)
- Validate all data before saving
- Handle LocalStorage quota exceeded errors

## 📦 DEPENDENCIES

**Production:**
- react: ^18.x
- react-dom: ^18.x

**Development:**
- vite: ^5.x
- typescript: ^5.x
- tailwindcss: ^3.x
- @types/react: ^18.x
- @types/react-dom: ^18.x

**Adding New Dependencies:**
Before adding a dependency, ask:
1. Is it really needed?
2. What's the bundle size impact?
3. Are there lighter alternatives?
4. Is it well-maintained?

## 🚀 DEPLOYMENT NOTES

This is a static site that can be deployed to:
- Vercel (recommended)
- Netlify
- GitHub Pages
- Any static hosting

Build command: `npm run build`
Output directory: `dist/`

## 📚 USEFUL REFERENCES

**When working on:**
- Dates: Use `date-fns` or native Date methods
- Forms: React controlled components
- Validation: Custom validation utilities in `utils/`
- Storage: LocalStorage wrapper in `utils/storage.ts`

## 🤝 COLLABORATION NOTES

**Before Starting Work:**
- Read the project guide document
- Understand the three principles
- Review existing code patterns

**When Asking for Help:**
- Provide specific error messages
- Share the relevant code
- Describe what you've tried
- Explain expected vs actual behavior

**Code Review Checklist:**
- [ ] Types are properly defined
- [ ] Error cases are handled
- [ ] Tests pass (if applicable)
- [ ] No console.logs remain
- [ ] Code follows project patterns
- [ ] Comments explain "why", not "what"

## 💡 REMEMBER

This is a learning project to practice vibe coding principles:
1. **Break it down** - Complex becomes simple
2. **Make it clear** - Ambiguous becomes precise  
3. **Expect failure** - Prepare for edge cases

Quality over speed. Understanding over completion. Learning over perfection.
